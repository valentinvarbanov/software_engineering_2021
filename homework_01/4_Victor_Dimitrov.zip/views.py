from django.http.response import JsonResponse
from django.shortcuts import render

from django.http import HttpResponse

from .models import Currency, CurrencySerializer

# Create your views here.

def index(request):
    return render(request, "index.html")

def trending(request):

    trending = Currency.objects.order_by('-price')[0]

    context = {
        "currency_name" : trending.name, 
        "currency_price" : str(trending.price)
    }

    return render(request, "trending.html", context)

def trending_json(request):

    trending = Currency.objects.order_by('-price')[0]

    serializer = CurrencySerializer(trending)

    return JsonResponse(serializer.data)


# 4 % 4 == 0 
def lucky(request):    
    currencies = Currency.objects.all()

    highest_cap_currency = currencies[0]
    current_highest_cap = highest_cap_currency.price + highest_cap_currency.supply

    for currency in currencies:
        current_currency_cap = currency.price * currency.supply

        if current_currency_cap > current_highest_cap:
            current_highest_cap = current_currency_cap
            highest_cap_currency = currency

    context = {
        "currency_name" : highest_cap_currency.name,
        "currency_code" : highest_cap_currency.code,
        "currency_price" : highest_cap_currency.price 
    }             

    return render(request, "lucky.html", context)
